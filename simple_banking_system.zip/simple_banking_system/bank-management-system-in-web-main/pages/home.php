<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DG Bank</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { font-family: Arial, sans-serif; }
        .hero { background-color:rgb(111, 249, 240); padding: 50px 0; }
        .hero h1 { font-size: 3rem; }
        .features { padding: 50px 0; }
        .feature { padding: 20px; border: 1px solid #ddd; border-radius: 10px; }
        footer { background-color:rgb(21, 249, 158); color: white; padding: 20px 0; }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">DG Bank</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Services</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero text-center">
        <div class="container">
            <h1>Welcome to DG Bank</h1>
            <p>Your trusted partner for financial growth.</p>
            <a href="register.php" class="btn btn-primary">Get Started</a>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features">
        <div class="container">
            <h2 class="text-center mb-4">Our Features</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="feature text-center">
                        <h3>Secure Banking</h3>
                        <p>Enjoy safe and secure transactions 24/7.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature text-center">
                        <h3>Easy Transfers</h3>
                        <p>Transfer money seamlessly across accounts.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature text-center">
                        <h3>24/7 Support</h3>
                        <p>We're here to help anytime, anywhere.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="text-center">
        <p>&copy; 2025 DG Bank. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
