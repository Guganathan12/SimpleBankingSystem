<?php
session_start();
if (!isset($_SESSION['AccNo'])) {
    header('Location: ../login.php?msg=Please login to continue');
    exit;
}

require('../../configs/db.php');
require('../../scripts/get_balance.php'); // $balance
require('../../scripts/get_interest.php'); // $interest
require('../../scripts/get_userinfo.php'); // $name, $fName, $pp
require('../../scripts/get_analytics.php'); // $totalDebit, $totalCredit
require('../../scripts/get_transactions.php'); // $trns

$error = '';
if (isset($_GET['msg'])) {
    $error = $_GET['msg'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Dashboard - DG Bank</title>
    <link rel="icon" href="../../assets/img/logol2.png" type="image/x-icon">
    <link rel="stylesheet" href="./css/index/mainMobile.css">
    <link rel="stylesheet" href="./css/index/table.css" media="(min-width: 600px)">
    <link rel="stylesheet" href="./css/index/desktop.css" media="(min-width: 900px)">
    <link rel="stylesheet" href="./css/all.min.css" />
    <link rel="stylesheet" href="./css/common.css" />
    <link rel="stylesheet" href="./css/newmew.css" />
    <style>
        body {
            background: linear-gradient(to right,rgb(190, 199, 214),rgb(191, 198, 208));
            font-family: Arial, sans-serif;
            transition: all 0.3s ease;
        }

        .card {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(237, 192, 192, 0.1);
            transition: transform 0.2s;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table tr:hover {
            background-color:rgb(199, 239, 243);
        }
        .overview-row {
    display: flex;
    flex-direction: column;
    gap: 15px;
    width: 100%;
}

.revenue-container {
    width: 100%;
    border-radius: 10px;
    padding: 20px;
    color: white;
    box-shadow: none;
    transition: background-color 0.3s ease;
}

/* Colored backgrounds for each card */
.revenue-container:nth-child(1) {
    background-color: #4a90e2;
}

.revenue-container:nth-child(2) {
    background-color: #50e3c2;
}

.revenue-container:nth-child(3) {
    background-color: #f5a623;
}

.revenue-container:nth-child(4) {
    background-color: #d0021b;
}
.revenue-container.transactions-container {
    margin-top: 30px;
    background-color: #3a6ea5;
    color: white;
    border-radius: 10px;
    padding: 20px;
}

.table-transactions {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 10px;
}

.table-transactions thead th {
    background-color: rgba(255, 255, 255, 0.2);
    color: white;
    padding: 10px;
    text-align: left;
}

.table-transactions tbody tr {
    background-color: rgba(255, 255, 255, 0.15);
    border-radius: 8px;
}

.table-transactions tbody tr:hover {
    background-color: rgba(255, 255, 255, 0.3);
}

.table-transactions tbody td {
    padding: 10px;
    color: white;
}

    </style>
</head>
<body class="dashboard">
    <div id="wrapper">
        <!-- Sidebar -->
        <nav class="navbar-side sidebar">
            <div class="nav-container">
                <a class="navbar-brand" href="./index.php">
                    <div class="sidebar-brand-icon rotate-n-15">
                        <img src="../../assets/img/logol2.png" height="50px">
                    </div>
                    <div class="sidebar-brand-text"><span>DG Bank</span></div>
                </a>
                <hr class="sidebar-divider">
                <ul class="navbar-nav" id="sidebar-ul">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">
                            <i class="fas fa-tachometer-alt"></i>
                            <span class="active-db">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="transfer.php">
                            <i class="fas fa-money-bill-alt"></i>
                            <span>Transfer</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="transactions.php">
                            <i class="fas fa-exchange-alt"></i>
                            <span>Transactions</span>
                        </a>
                    </li>
        
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i>
                            <span>Profile</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="settings.php">
                            <i class="fas fa-adjust"></i>
                            <span>Settings</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../scripts/logout.php">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Log out</span>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Content Wrapper -->
        <div id="content-wrapper">
            <!-- Topbar -->
            <div class="navbar-top d-flex" id="page-top">
                <div class="container-fluid d-flex"></div>
                <ul class="navbar-nav-ul d-flex">
                    <li class="nav-item">
                        <a class="dropdown-toggle nav-link search-icon-nav" href="#"><i class="fas fa-search"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="dropdown-toggle nav-link" href="#"><i class="fas fa-bell fa-fw"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="dropdown-toggle nav-link" href="#"><i class="fas fa-envelope fa-fw"></i></a>
                    </li>
                    <div class="topbar-divider"></div>
                    <li class="nav-item avatar-n">
                        <p><span class="avatar-text"><?php echo $name; ?></span></p>
                        <div class="avatar-nav" style="background-image: url(<?php echo $pp ?>);"></div>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="index-content container-main">
                <div class="dashboard-header d-flex justify-between">
                    <h2>Dashboard</h2>
                </div>
                 <header>
            <h3>Welcome, <?php echo $fName; ?></h3>
        </header>
                <!-- Info Cards -->
                <div class="overview-row row d-flex flex-wrap">
                    <div class="revenue revenue-container card-width row2-bgEdit">
                        <h4 class="revenue-header-text">Balance</h4>
                        <p class="card-value">Rs. <?php echo $balance; ?></p>
                    </div>
                    <div class="revenue revenue-container card-width row2-bgEdit">
                        <h4 class="revenue-header-text">Interest</h4>
                        <p class="card-value">Rs. <?php echo $interest; ?></p>
                    </div>
                    <div class="revenue revenue-container card-width row2-bgEdit">
                        <h4 class="revenue-header-text">Income</h4>
                        <p class="card-value">Rs. <?php echo $totalCredit; ?></p>
                    </div>
                    <div class="revenue revenue-container card-width row2-bgEdit">
                        <h4 class="revenue-header-text">Expense</h4>
                        <p class="card-value">Rs. <?php echo $totalDebit; ?></p>
                    </div>
                </div>

                <!-- Transactions Table -->
                <div class="revenue revenue-container row2-bgEdit transactions-container" style="width: 100%;">
                    <div class="revenue-header d-flex justify-between">
                        <h6 class="revenue-header-text">Recent Transactions</h6>
                    </div>
                    <div class="user-setting-body project-body">
                        <table class="table-transactions">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Description</th>
                                    <th>Amount</th>
                                    <th>Remarks</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 0;
                                foreach ($trns as $trn) {
                                    if ($count >= 5) break;
                                    $date = date("d-m-Y", strtotime($trn['DateTime']));
                                    $sender = $trn['Sender'];
                                    $receiver = $trn['Receiver'];
                                    $amount = $trn['Amount'];
                                    $remarks = $trn['Remarks'];

                                    if ($sender == $_SESSION['AccNo']) {
                                        echo "<tr><td>Debit</td><td>To $receiver</td><td>Rs. $amount</td><td>$remarks</td><td>$date</td></tr>";
                                    } else {
                                        echo "<tr><td>Credit</td><td>From $sender</td><td>Rs. $amount</td><td>$remarks</td><td>$date</td></tr>";
                                    }
                                    $count++;
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div> <!-- End index-content -->
        </div> <!-- End content-wrapper -->
    </div> <!-- End wrapper -->
</body>
</html>
