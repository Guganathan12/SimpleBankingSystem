<?php
// Database Connection
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$databasename = "bms";
$conn = mysqli_connect($host, $dbusername, $dbpassword, $databasename);